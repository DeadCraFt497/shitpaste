package me.ciruu.abyss.enums;

/*
 * Exception performing whole class analysis ignored.
 */
public enum Class246 {
    IS_FULL_CHUNK,
    TIMING,
    BLOCK_CHANGE_THRESHOLD,
    DECORATOR_BLOCKS_DETECTED;

}
