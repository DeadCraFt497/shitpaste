package me.ciruu.abyss.enums;

/*
 * Exception performing whole class analysis ignored.
 */
public enum Class158 {
    Auto,
    MainHand,
    OffHand;

}
