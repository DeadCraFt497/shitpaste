package me.ciruu.abyss;

public class Class307 {
    private Object Field2446;
    private Object Field2447;

    public Class307(Object object, Object object2) {
        this.Field2446 = object;
        this.Field2447 = object2;
    }

    public void Method2968(Object object) {
        this.Field2446 = object;
    }

    public void Method2969(Object object) {
        this.Field2447 = object;
    }

    public Object Method2970() {
        return this.Field2446;
    }

    public Object Method1109() {
        return this.Field2447;
    }
}
