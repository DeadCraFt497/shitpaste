package me.ciruu.abyss;

import java.awt.Color;
import org.jetbrains.annotations.NotNull;

public final class Class74 {
    @NotNull
    private static Color Field544;
    @NotNull
    private static Color Field545;
    @NotNull
    private static Color Field546;
    @NotNull
    private static Color Field547;
    @NotNull
    private static Color Field548;
    @NotNull
    private static Color Field549;
    @NotNull
    private static Color Field550;
    public static final Class74 Field172;

    @NotNull
    public final Color Method165() {
        return Field544;
    }

    public final void getColor(@NotNull Color color) {
        Field544 = color;
    }

    @NotNull
    public final Color Method413() {
        return Field545;
    }

    public final void Method695(@NotNull Color color) {
        Field545 = color;
    }

    @NotNull
    public final Color Method702() {
        return Field546;
    }

    public final void Method696(@NotNull Color color) {
        Field546 = color;
    }

    @NotNull
    public final Color Method171() {
        return Field547;
    }

    public final void Method693(@NotNull Color color) {
        Field547 = color;
    }

    @NotNull
    public final Color Method703() {
        return Field548;
    }

    public final void Method697(@NotNull Color color) {
        Field548 = color;
    }

    @NotNull
    public final Color Method704() {
        return Field549;
    }

    public final void Method698(@NotNull Color color) {
        Field549 = color;
    }

    @NotNull
    public final Color Method412() {
        return Field550;
    }

    public final void Method694(@NotNull Color color) {
        Field550 = color;
    }

    private Class74() {
    }

    static {
        Class74 class74;
        Field172 = class74 = new Class74();
        Field544 = new Color(58, 58, 61, 255);
        Field545 = new Color(49, 200, 200, 255);
        Field546 = new Color(49, 200, 200, 255);
        Field547 = new Color(255, 255, 255, 255);
        Field548 = new Color(0, 255, 255, 255);
        Field549 = new Color(0, 255, 255, 255);
        Field550 = new Color(160, 0, 160, 255);
    }
}
