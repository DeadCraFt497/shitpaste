package me.ciruu.abyss;

import me.ciruu.abyss.events.MinecraftEvent;

public class Class66
extends MinecraftEvent {
    private float Field1381;

    public Class66(float f) {
        this.Field1381 = f;
    }

    public float Method1789() {
        return this.Field1381;
    }
}
