package me.ciruu.abyss;

import me.ciruu.abyss.enums.Class433;

/*
 * Exception performing whole class analysis ignored.
 */
public class Class432 {
    static final int[] Field1437 = new int[Class433.values().length];

    static {
        try {
            Class432.Field1437[Class433.Yes.ordinal()] = 1;
        }
        catch (NoSuchFieldError noSuchFieldError) {
            // empty catch block
        }
    }
}
