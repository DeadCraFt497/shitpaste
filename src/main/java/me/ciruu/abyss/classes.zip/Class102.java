package me.ciruu.abyss;

import me.ciruu.abyss.Class101;

/*
 * Exception performing whole class analysis ignored.
 */
public final class Class102 {
    public static void Method1978(Class101 class101, int n, int n2) {
    }

    public static void Method1979(Class101 class101, int n, int n2) {
    }

    public static void Method1980(Class101 class101, int n, int n2, int n3) {
    }

    public static void Method1981(Class101 class101, int n, int n2, int n3) {
    }

    public static void Method1982(Class101 class101, int n, int n2, int n3, long l) {
    }

    public static void Method1983(Class101 class101, char c, int n) {
    }

    public static void Method1984(Class101 class101, int n) {
    }

    public static boolean Method1985(Class101 class101, int n, int n2) {
        float f = class101.Method240() - (float)n;
        int n3 = 2;
        boolean bl = false;
        float f2 = (float)Math.pow(f, n3);
        f = class101.Method242() - (float)n2;
        n3 = 2;
        float f3 = f2;
        bl = false;
        float f4 = (float)Math.pow(f, n3);
        f = class101.Method244();
        n3 = 2;
        f3 += f4;
        bl = false;
        f4 = (float)Math.pow(f, n3);
        return f3 <= f4;
    }
}
