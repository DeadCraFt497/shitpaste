package me.ciruu.abyss;

/*
 * Exception performing whole class analysis ignored.
 */
@Deprecated
public class Class502 {
    public final int Field1828;
    public final int Field1827;
    public final boolean Field1826;
    public final double Field2468;
    public final double Field2469;

    public Class502(double d, double d2, boolean bl) {
        this.Field1828 = (int)d;
        this.Field1827 = (int)d2;
        this.Field2468 = d;
        this.Field2469 = d2;
        this.Field1826 = bl;
    }
}
