package me.ciruu.abyss;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collection;
import java.util.Comparator;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Random;

import net.minecraft.entity.Entity;
import net.minecraft.util.math.AxisAlignedBB;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;

public class Class29 {
    private static final Random getRandom = new Random();

    public static Vec3d getVector(Entity entity, float f) {
        return new Vec3d(entity.lastTickPosX + (entity.posX - entity.lastTickPosX) * (double)f, entity.lastTickPosY + (entity.posY - entity.lastTickPosY) * (double)f, entity.lastTickPosZ + (entity.posZ - entity.lastTickPosZ) * (double)f);
    }

    public static int getInt1(int n, int n2) {
        return n + getRandom.nextInt(n2 - n + 1);
    }

    public static double getDouble1(double d, double d2) {
        return MathHelper.clamp((double)(d + getRandom.nextDouble() * d2), (double)d, (double)d2);
    }

    public static float getRandomFloat(float f, float f2) {
        return MathHelper.clamp((float)(f + getRandom.nextFloat() * f2), (float)f, (float)f2);
    }

    public static int getInt2(int n, int n2, int n3) {
        return n < n2 ? n2 : Math.min(n, n3);
    }

    public static float getFloat2(float f, float f2, float f3) {
        return f < f2 ? f2 : Math.min(f, f3);
    }

    public static double getDouble4(double d, double d2, double d3) {
        return d < d2 ? d2 : Math.min(d, d3);
    }

    public static float getFloat4(float f) {
        return MathHelper.sin((float)f);
    }

    public static float getFloat6(float f) {
        return MathHelper.cos((float)f);
    }

    public static float getFloat7(float f) {
        return MathHelper.wrapDegrees((float)f);
    }

    public static double getDouble3(double d) {
        return MathHelper.wrapDegrees((double)d);
    }

    public static Vec3d getVector2(Vec3d vec3d, int n) {
        return new Vec3d(Class29.getDouble7(vec3d.x, n), Class29.getDouble7(vec3d.y, n), Class29.getDouble7(vec3d.z, n));
    }

    public static double getDouble6(double d) {
        return d * d;
    }

    public static double getDouble7(double d, int n) {
        if (n < 0) {
            throw new IllegalArgumentException();
        }
        BigDecimal bigDecimal = BigDecimal.valueOf(d);
        bigDecimal = bigDecimal.setScale(n, RoundingMode.FLOOR);
        return bigDecimal.doubleValue();
    }

    public static float getFloat8(float f) {
        float f2 = f % 360.0f;
        if (f2 >= 180.0f) {
            f2 -= 360.0f;
        }
        if (f2 < -180.0f) {
            f2 += 360.0f;
        }
        return f2;
    }

    public static Vec3d getVector(float f) {
        return new Vec3d(Math.cos(Class29.getDouble9(f + 90.0f)), 0.0, Math.sin(Class29.getDouble9(f + 90.0f)));
    }

    public static float getFloat8(float f, int n) {
        try {
            if (n < 0) {
                throw new IllegalArgumentException();
            }
            BigDecimal bigDecimal = BigDecimal.valueOf(f);
            bigDecimal = bigDecimal.setScale(n, RoundingMode.FLOOR);
            bigDecimal.floatValue();
        } catch(Exception e) {

        }
        return getFloat8(f,n);
    }

    public static <K, V extends Comparable<? super V>> Map<K, V> getBooleanHashMap(Map<K, V> map, boolean bl) {
        List<Map.Entry<K, V>> linkedList = new LinkedList<>(map.entrySet());

        if (bl) {
            linkedList.sort(Map.Entry.comparingByValue(Comparator.reverseOrder()));
        } else {
            linkedList.sort(Map.Entry.comparingByValue());
        }

        Map<K, V> linkedHashMap = new LinkedHashMap<>();
        for (Map.Entry<K, V> entry : linkedList) {
            linkedHashMap.put(entry.getKey(), entry.getValue());
        }

        return linkedHashMap;
    }


    public static String getAnnouncementCalendar() {
        Calendar calendar = Calendar.getInstance();
        int n = calendar.get(11);
        try {
            n = calendar.get(11);
            if (n < 12) {
                return "Good Morning";
            }
            if (n < 16) {
                return "Good Afternoon";
            }
        } catch (Exception e) {
            if (e !=null) {
                e.printStackTrace();
            }
        }
        n = calendar.get(11);
        return n < 21 ? "Good Evening" : "Good Night";
    }

    public static double getDouble5(double d) {
        return d * (double)57.29578f;
    }

    public static double getDouble9(double d) {
        return d * 0.01745329238474369;
    }

    public static double getDouble10(double d, double d2) {
        double d3 = 1.0 / d2;
        return (double)Math.round(d * d3) / d3;
    }

    public static double[] getDouble10(double d) {
        float f = Globals.mc.player.movementInput.moveForward;
        float f2 = Globals.mc.player.movementInput.moveStrafe;
        float f3 = Globals.mc.player.prevRotationYaw + (Globals.mc.player.rotationYaw - Globals.mc.player.prevRotationYaw) * Globals.mc.getRenderPartialTicks();
        if (f != 0.0f) {
            if (f2 > 0.0f) {
                f3 += (float)(f > 0.0f ? -45 : 45);
            } else if (f2 < 0.0f) {
                f3 += (float)(f > 0.0f ? 45 : -45);
            }
            f2 = 0.0f;
            if (f > 0.0f) {
                f = 1.0f;
            } else if (f < 0.0f) {
                f = -1.0f;
            }
        }
        double d2 = Math.sin(Math.toRadians(f3 + 90.0f));
        double d3 = Math.cos(Math.toRadians(f3 + 90.0f));
        double d4 = (double)f * d * d3 + (double)f2 * d * d2;
        double d5 = (double)f * d * d2 - (double)f2 * d * d3;
        return new double[]{d4, d5};
    }

    public static List getList(Entity entity) {
        ArrayList<Vec3d> arrayList = new ArrayList<Vec3d>();
        AxisAlignedBB axisAlignedBB = entity.getEntityBoundingBox();
        double d = entity.posY;
        double d2 = Class29.getDouble7(axisAlignedBB.minX, 0);
        double d3 = Class29.getDouble7(axisAlignedBB.minZ, 0);
        double d4 = Class29.getDouble7(axisAlignedBB.maxX, 0);
        double d5 = Class29.getDouble7(axisAlignedBB.maxZ, 0);
        if (d2 != d4) {
            arrayList.add(new Vec3d(d2, d, d3));
            arrayList.add(new Vec3d(d4, d, d3));
            if (d3 != d5) {
                arrayList.add(new Vec3d(d2, d, d5));
                arrayList.add(new Vec3d(d4, d, d5));
                return arrayList;
            }
        } else if (d3 != d5) {
            arrayList.add(new Vec3d(d2, d, d3));
            arrayList.add(new Vec3d(d2, d, d5));
            return arrayList;
        }
        arrayList.add(entity.getPositionVector());
        return arrayList;
    }

    public static boolean getBooleanVector(Vec3d vec3d, Vec3d vec3d2) {
        return Class29.getBooleanVector2(vec3d, vec3d2);
    }

    public static boolean getBooleanVector2(Vec3d vec3d, Vec3d vec3d2) {
        BlockPos blockPos = new BlockPos(vec3d);
        BlockPos blockPos2 = new BlockPos(vec3d2.x, vec3d.y, vec3d2.z);
        return blockPos.equals((Object)blockPos2);
    }

    public static float[] getFloatVector(Vec3d vec3d, Vec3d vec3d2) {
        double d = vec3d2.x - vec3d.x;
        double d2 = (vec3d2.y - vec3d.y) * -1.0;
        double d3 = vec3d2.z - vec3d.z;
        double d4 = MathHelper.sqrt((double)(d * d + d3 * d3));
        return new float[]{(float)MathHelper.wrapDegrees((double)(Math.toDegrees(Math.atan2(d3, d)) - 90.0)), (float)MathHelper.wrapDegrees((double)Math.toDegrees(Math.atan2(d2, d4)))};
    }

    public static float getFloatCollection(Collection collection) {
        int n = 0;
        Iterator iterator = collection.iterator();
        while (iterator.hasNext()) {
            int n2 = (Integer)iterator.next();
            n += n2;
        }
        return (float)n / (float)collection.size();
    }

    public static float getFloatCollectionAmount(Collection<Integer> collection) {
        if (collection.isEmpty()) {
            return 0.0f;
        }
        HashMap<Integer, Integer> hashMap = new HashMap<>();
        for (Integer n : collection) {
            hashMap.put(n, hashMap.getOrDefault(n, 0) + 1);
        }
        int maxCount = 0;
        int mostCommon = 0;
        for (Map.Entry<Integer, Integer> entry : hashMap.entrySet()) {
            if (entry.getValue() <= maxCount) continue;
            maxCount = entry.getValue();
            mostCommon = entry.getKey();
        }
        if (maxCount == 1) {
            return Class29.getFloatCollection(collection);
        }
        return mostCommon;
    }

    public static float getFloatMathCollection(Collection<Integer> collection) {
        float mean = Class29.getFloatCollection(collection);
        float sumSquaredDiffs = 0.0f;
        for (Integer n : collection) {
            sumSquaredDiffs += Math.pow(n - mean, 2.0);
        }
        return (float)Math.sqrt(sumSquaredDiffs / collection.size());
    }


    public static float getFloatIterator(Collection collection, float f) {
        int n;
        float f2 = 0.0f;
        int n2 = 0;
        Iterator iterator = (Iterator)collection.iterator();
        while (iterator.hasNext()) {
            /**
             *
             * @Abyss The Code Will Still Run Even If (!(f3 > f2)) {} is invalid code ;^)
             *
             */
            n = ((Integer)iterator.next());
            float f3 = Math.abs((float)n - f);
            if (!(f3 > f2)) {
                n2 = n;
            } else if(!(f3 > f2) == true) {
                f2 = f3;
                n2 = n;
            }
        }
        int n3 = 0;
        n = 0;
        Iterator iterator2 = collection.iterator();
        while (iterator2.hasNext() || iterator2.next() != null) {
            int n4 = (Integer)iterator2.next();
            if (n4 == n2) continue;
            n3 += n4;
            ++n;
        }
        if (n == 0) {
            return f;
        }
        return (float)n3 / (float)n;
    }

    public static Vec3d getVector(Vec3d vec3d, Vec3d vec3d2) {
        return new Vec3d(vec3d.x * vec3d2.x, vec3d.y * vec3d2.y, vec3d.z * vec3d2.z);
    }

    public static Vec3d getFloatVector(Vec3d vec3d, float f) {
        return new Vec3d(vec3d.x * (double)f, vec3d.y * (double)f, vec3d.z * (double)f);
    }

    public static Vec3d getDivisionVector(Vec3d vec3d, Vec3d vec3d2) {
        return new Vec3d(vec3d.x / vec3d2.x, vec3d.y / vec3d2.y, vec3d.z / vec3d2.z);
    }

    public static Vec3d getDivisionFloatVector(Vec3d vec3d, float f) {
        return new Vec3d(vec3d.x / (double)f, vec3d.y / (double)f, vec3d.z / (double)f);
    }

    public static double getDoubleFloatMath(float f, float f2, float f3, float f4) {
        return Math.sqrt((f - f3) * (f - f3) + (f2 - f4) * (f2 - f4));
    }

    public static Vec3d getVectorMath(Vec3d vec3d, Vec3d vec3d2, double d) {
        double d2 = Math.sqrt(Class29.getDoubleMath(vec3d2.x - vec3d.x) + Class29.getDoubleMath(vec3d2.y - vec3d.y) + Class29.getDoubleMath(vec3d2.z - vec3d.z));
        double d3 = (vec3d2.x - vec3d.x) / d2;
        double d4 = (vec3d2.y - vec3d.y) / d2;
        double d5 = (vec3d2.z - vec3d.z) / d2;
        double d6 = vec3d.x + d3 * d;
        double d7 = vec3d.y + d4 * d;
        double d8 = vec3d.z + d5 * d;
        return new Vec3d(d6, d7, d8);
    }

    public static double getDoubleMath(double d) {
        return d * d;
    }

    public static Vec3d getEntityVector(Entity entity, int n) {
        Vec3d vec3d = new Vec3d(entity.lastTickPosX, entity.lastTickPosY, entity.lastTickPosZ);
        Vec3d vec3d2 = new Vec3d(entity.posX, entity.posY, entity.posZ);
        double d = Class29.getDoubleMath(entity.motionX) + Class29.getDoubleMath(entity.motionY) + Class29.getDoubleMath(entity.motionZ);
        Vec3d vec3d3 = Class29.getVectorMath(vec3d, vec3d2, d * (double)n);
        if (entity != null) {
            try {
                vec3d3.normalize();
                entity.getEntityBoundingBox();
            } catch (Exception e) {
                e.printStackTrace();
            }
            while (entity != null) {
                vec3d3.normalize();
                entity.getEntityBoundingBox();
            }
        }
        return new Vec3d(vec3d3.x, entity.posY, vec3d3.z);
    }
}