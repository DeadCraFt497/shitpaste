package me.ciruu.abyss;

import me.zero.alpine.fork.listener.EventHandler;

public class Class22 {
    private long long1 = -1L;
    private long long2;

    {
        Class22 class22 = this;
    }

    public boolean getBooleanTime2(double d) {
        return this.getLongMath(System.nanoTime() - this.long1) >= (long)(d * 1000.0);
    }

    public boolean getBooleanTime1(double d) {
        return this.getLongMath(System.nanoTime() - this.long1) >= (long)(d * 1000.0 * 60.0);
    }

    public boolean getBooleanTime3(double d) {
        return this.getLongMath(System.nanoTime() - this.long1) >= (long)(d * 10.0);
    }

    public boolean getBooleanTime4(double d) {
        return this.getLongMath(System.nanoTime() - this.long1) >= (long)(d * 100.0);
    }

    public boolean getLongNanoTime(long l) {
        return this.getLongMath(System.nanoTime() - this.long1) >= l;
    }

    public boolean getLongNanoTime2(long l) {
        return System.nanoTime() - this.long1 >= l;
    }

    public void getLongNanoTime3(long l) {
        this.long1 = System.nanoTime() - l * 1000000L;
    }

    public long getLongNanoTimeMeth() {
        return this.getLongMath(System.nanoTime() - this.long1);
    }

    public final boolean getLongNanoTime4(long l) {
        return System.currentTimeMillis() - this.long2 >= l;
    }

    public void getNanoTime() {
        Class22 class22 = this;
        this.long1 = System.nanoTime();
    }

    public long getLongMath(long l) {
        Class22 class22 = this;
        return l / 1000000L;
    }

    public long getLongReturnType() {
        return this.long1;
    }
}
