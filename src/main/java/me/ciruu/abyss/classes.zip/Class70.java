package me.ciruu.abyss;

import me.ciruu.abyss.settings.Setting;
import org.jetbrains.annotations.Nullable;

public interface Class70 {
    @Nullable
    public Class70 Method2231();

    @Nullable
    public Setting Method2232();

    public int Method2233();

    public void Method2234(int var1);

    public int Method2235();

    public void Method2236(int var1);

    public int Method2237();

    public int Method2238();

    public boolean Method2239();

    public void Method2240(boolean var1);

    public int Method2241();

    public int Method2242();

    public int Method2243();

    public void Method2244();

    public void Method2245(int var1, int var2);

    public void Method2246(int var1, int var2, int var3);

    public void Method2247(int var1, int var2, int var3);

    public void Method2248(int var1, int var2, int var3, long var4);

    public void Method2249(char var1, int var2);

    public void Method2250(int var1);

    public boolean Method2251(int var1, int var2);
}
