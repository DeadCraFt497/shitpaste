package me.ciruu.abyss;

import me.ciruu.abyss.enums.Class167;

/*
 * Exception performing whole class analysis ignored.
 */
public class Class166 {
    static final int[] Field363 = new int[Class167.values().length];

    static {
        try {
            Class166.Field363[Class167.Register.ordinal()] = 1;
        }
        catch (NoSuchFieldError noSuchFieldError) {
            // empty catch block
        }
        try {
            Class166.Field363[Class167.Login.ordinal()] = 2;
        }
        catch (NoSuchFieldError noSuchFieldError) {
            // empty catch block
        }
    }
}
