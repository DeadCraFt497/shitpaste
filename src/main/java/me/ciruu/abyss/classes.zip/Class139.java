package me.ciruu.abyss;

import me.ciruu.abyss.events.MinecraftEvent;
import me.ciruu.abyss.modules.Module;

public class Class139
extends MinecraftEvent {
    private final Module Field2777;

    public Class139(Module module) {
        this.Field2777 = module;
    }

    public Module Method1564() {
        return this.Field2777;
    }
}
