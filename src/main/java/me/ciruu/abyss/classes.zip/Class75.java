package me.ciruu.abyss;

import me.ciruu.abyss.Class70;

/*
 * Exception performing whole class analysis ignored.
 */
public final class Class75 {
    public static int Method183(Class70 class70) {
        return 0;
    }

    public static int Method184(Class70 class70) {
        Class70 class702 = class70.Method2231();
        return class70.Method2233() + (class702 != null ? class702.Method2242() : 0);
    }

    public static int Method185(Class70 class70) {
        Class70 class702 = class70.Method2231();
        return class70.Method2235() + (class702 != null ? class702.Method2243() : 0);
    }

    public static void Method2713(Class70 class70) {
    }

    public static void Method433(Class70 class70, int n, int n2) {
    }

    public static void Method1618(Class70 class70, int n, int n2, int n3) {
    }

    public static void Method187(Class70 class70, int n, int n2, int n3) {
    }

    public static void Method189(Class70 class70, int n, int n2, int n3, long l) {
    }

    public static void Method1622(Class70 class70, char c, int n) {
    }

    public static void Method191(Class70 class70, int n) {
    }

    public static boolean Method192(Class70 class70, int n, int n2) {
        return n > class70.Method2242() && n < class70.Method2242() + class70.Method2237() && n2 > class70.Method2243() && n2 < class70.Method2243() + class70.Method2238();
    }
}
