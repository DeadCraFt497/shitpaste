package me.ciruu.abyss;

public class Class25 {
    private String string1 = new String(String.valueOf(null));

    public Class25(String string) {
        this.string1 = string;
    }

    public String getString() {
        return this.string1;
    }

    public void getStringReturnType(String string) {
        this.string1 = string;
    }
}
