package me.ciruu.abyss;

import me.ciruu.abyss.enums.Class588;

/*
 * Exception performing whole class analysis ignored.
 */
public class Class640 {
    static final int[] Field2905 = new int[Class588.values().length];

    static {
        try {
            Class640.Field2905[Class588.Chest.ordinal()] = 1;
        }
        catch (NoSuchFieldError noSuchFieldError) {
            // empty catch block
        }
        try {
            Class640.Field2905[Class588.Ender.ordinal()] = 2;
        }
        catch (NoSuchFieldError noSuchFieldError) {
            // empty catch block
        }
        try {
            Class640.Field2905[Class588.Shulker.ordinal()] = 3;
        }
        catch (NoSuchFieldError noSuchFieldError) {
            // empty catch block
        }
        try {
            Class640.Field2905[Class588.Furnace.ordinal()] = 4;
        }
        catch (NoSuchFieldError noSuchFieldError) {
            // empty catch block
        }
        try {
            Class640.Field2905[Class588.Hopper.ordinal()] = 5;
        }
        catch (NoSuchFieldError noSuchFieldError) {
            // empty catch block
        }
        try {
            Class640.Field2905[Class588.Dispenser.ordinal()] = 6;
        }
        catch (NoSuchFieldError noSuchFieldError) {
            // empty catch block
        }
    }
}
