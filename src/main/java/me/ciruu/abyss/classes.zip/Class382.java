package me.ciruu.abyss;

/*
 * Exception performing whole class analysis ignored.
 */
public final class Class382 {
    public static final int Field1257 = 17;
    public static final int Field1258 = 18;
    public static final int Field1259 = 33;
    public static final int Field1260 = 34;
    public static final int Field1261 = 5;
    public static final int Field1262 = 6;
    public static final int Field1263 = 9;
    public static final int Field1264 = 10;
    public static final int Field1265 = 20;
    public static final int Field1266 = 36;
    public static final int Field1267 = 24;
    public static final int Field1268 = 40;
    public static final int Field1269 = 63;
}
