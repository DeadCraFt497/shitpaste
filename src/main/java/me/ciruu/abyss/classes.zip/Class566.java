package me.ciruu.abyss;

public class Class566 {
    static {
        System.out.println("Nice try");
    }
}
