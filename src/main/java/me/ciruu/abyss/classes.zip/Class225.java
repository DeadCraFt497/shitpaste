package me.ciruu.abyss;

import me.ciruu.abyss.enums.Class226;

/*
 * Exception performing whole class analysis ignored.
 */
public class Class225 {
    static final int[] Field536 = new int[Class226.values().length];

    static {
        try {
            Class225.Field536[Class226.Preserve.ordinal()] = 1;
        }
        catch (NoSuchFieldError noSuchFieldError) {
            // empty catch block
        }
        try {
            Class225.Field536[Class226.Up.ordinal()] = 2;
        }
        catch (NoSuchFieldError noSuchFieldError) {
            // empty catch block
        }
        try {
            Class225.Field536[Class226.Down.ordinal()] = 3;
        }
        catch (NoSuchFieldError noSuchFieldError) {
            // empty catch block
        }
        try {
            Class225.Field536[Class226.Bounds.ordinal()] = 4;
        }
        catch (NoSuchFieldError noSuchFieldError) {
            // empty catch block
        }
    }
}
